# urls.py
from django.contrib import admin
from django.urls import path, include
from helloworldproject import views 
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    #path('login',views.Login.login),
    path('login',views.login),
    path('newuser',views.newuser)
]