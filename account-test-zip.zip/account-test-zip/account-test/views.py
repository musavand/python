from django.shortcuts  import render
from django.http import HttpResponse
from django.views.generic import View
from django.shortcuts import render
from django.views.decorators.csrf import csrf_protect

def answer (request):
    return HttpResponse("hello musavand")

def home(request):
    return HttpResponse('تست مدیریت دسترسی کاربران')

def wellcome(request) :        
    return render(request, 'wellcome.html')
def error(request) :        
    return render(request, 'error.html')

def newuser(request) :  
    if request.method == 'GET':
       return render(request, 'newuser.html')
    else:
        email = request.POST.get("email")
        FirstName = request.POST.get("FirstName")
        FirstName = request.POST.get("FirstName")
        Mobile = request.POST.get("FirstName")      
        return redirect(wellcome)



@csrf_protect
def login(request):   
    if request.method == 'GET':
        return render(request, 'login.html')
    else:
        email = request.POST.get("email")
        password = request.POST.get("password")
        if email=='mehdi@yahoo.com':
             return redirect(wellcome)
         #else   return redirect(error)       

   